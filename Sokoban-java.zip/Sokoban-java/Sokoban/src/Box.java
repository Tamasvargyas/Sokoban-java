/**
 * A class designed to represent a box in Sokoban
 *
 */
public class Box extends Block {

	private static final long serialVersionUID = -14832991580080577L;

	/**
	 * The Constructor of Box Where you can set the position of it
	 * @param pos The desired Position of the created Box
	 * @see Position
	 */
	public Box(Position pos) {
		super(pos, BlockType.BOX, true, false, null, null);
	}
	
	/**
	 * The Constructor of Box Where you can set the position of it,
	 * and a Block to put it on
	 * @param pos The desired Position of the created Box
	 * @param bo The Block to put the Box on
	 * @see Block
	 */
	public Box(Position pos, Block bo) {
		super(pos, BlockType.BOX, true, false, null, bo);
	}

}
