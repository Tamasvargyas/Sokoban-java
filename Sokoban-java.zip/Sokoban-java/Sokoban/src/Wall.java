/**
 * A class designed to represent a unit of a wall in Sokoban
 *
 */
public class Wall extends Block{

	private static final long serialVersionUID = -6288783347069320021L;

	/**
	 * Default constructor of class Wall
	 */
	public Wall() {
		super(new Position(0,0), BlockType.WALL, false, true, new Block(), null);
	}
	
	/**
	 * The Constructor of Wall where you can set the position of it
	 * @param pos The desired Position of the created Wall
	 * @see Position
	 */
	public Wall(Position pos) {
		super(pos, BlockType.WALL, false, true, new Block(), null);
	}

}
