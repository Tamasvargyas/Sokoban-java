
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.junit.Test;

/**
 * Test cases for the class SokobanMap
 *
 */
public class SokobanMapTest {

	@Test
	public void testConstuctFromTxtCustomType() {
		SokobanMap map = null;
		try {
			map = new SokobanMap("mapsTxt/map1.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		assertEquals("Level 1", map.getName());
		assertEquals(11, map.getHeight());
		assertEquals(11, map.getWidth());
		assertEquals(3, map.getBoxCount());
		assertEquals(0, map.getStepsTaken());
	}
	
	@Test
	public void testConstructFromTxtGenericType() {
		SokobanMap map = null;
		try {
			map = new SokobanMap("mapsTxt/map6.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		assertEquals("Level 6", map.getName());
		assertEquals(8, map.getHeight());
		assertEquals(8, map.getWidth());
		assertEquals(3, map.getBoxCount());
		assertEquals(0, map.getStepsTaken());
	}
	
	@Test
	public void testBestScore() {
		SokobanMap map = null;
		try {
			map = new SokobanMap("mapsTxt/map1.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		assertEquals(0, map.getBestScore());
		map.setBestScore(100);
		assertEquals(100, map.getBestScore());
		
	}
	
	@Test
	public void testBestPlayer() {
		SokobanMap map = null;
		try {
			map = new SokobanMap("mapsTxt/map4.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		assertEquals(null, map.getBestScorePlayer());
		
		map.setBestScorePlayer("Best player");
		assertEquals("Best player", map.getBestScorePlayer());
	}
	
	@Test
	public void testGameEnd() {
		SokobanMap map = null;
		try {
			map = new SokobanMap("mapsTxt/map3.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		assertFalse(map.gameFinished());
		assertFalse(map.newHighScore());
	}
	
	@Test
	public void stepTest() {
		SokobanMap map = null;
		try {
			map = new SokobanMap("mapsTxt/map6.txt");
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}		
		assertEquals(Block.BlockType.CHARACTER, map.getBlockTypeToPrint(5, 4));
		assertEquals(0, map.getStepsTaken());
		
		try {
			List<SokobanMap.ChangedBlock> list = map.step('d');
			assertEquals(list.get(0).getPos().getX(), 5);
			assertEquals(list.get(0).getPos().getY(), 4);
			assertEquals(list.get(0).getType(), Block.BlockType.FLOOR);
			
			assertEquals(list.get(1).getPos().getX(), 5);
			assertEquals(list.get(1).getPos().getY(), 5);
			assertEquals(list.get(1).getType(), Block.BlockType.CHARACTER);
			assertEquals(1, map.getStepsTaken());
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		try {
			List<SokobanMap.ChangedBlock> list = map.step('d');
			assertTrue(list.isEmpty());
			assertEquals(1, map.getStepsTaken());
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
