/**
 * A class designed to represent a unit of the floor in Sokoban
 *
 */
public class Floor extends Block{
	
	private static final long serialVersionUID = 1305513894767273262L;

	/**
	 * The Constructor of Floor where you can set the position of it
	 * @param pos The desired Position of the created Floor
	 * @see Position
	 */
	public Floor(Position pos) {
		super(pos, BlockType.FLOOR, false, false, null, null);
	}
	
	/**
	 * The Constructor of Floor where you can set the position of it,
	 * and a Block thats on the created Floor
	 * @param pos The desired Position of the created Floor
	 * @param ba The Block to put on top of the created Floor
	 * @see Position
	 */
	public Floor(Position pos, Block ba) {
		super(pos, BlockType.FLOOR, false, true, ba, null);
	}
	
	/**
	 * Returns the type of Block that should be visible from above the map
	 * witch can be three types in a Floors case:
	 * FLOOR - if nothing is on top of it (null)
	 * BOX - if a Box is on top
	 * CHARACTER - if the Character is on top
	 * @return The type of block to show
	 * @see BlockType
	 */
	@Override
	public BlockType getTypeToPrint() {
		if(hasBlockOnTop()) {
			return getBlockAbove().getType();
		} else {
			return getType();
		}
	}

}
