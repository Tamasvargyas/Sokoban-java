import java.io.Serializable;

/**
 * A class that represents a position given by coordinates
 * with usefull methods.
 *
 */
public class Position implements Serializable{

	private static final long serialVersionUID = 1785928432202231834L;
	
	private int x;
	private int y;
	
	/**
	 * Default constructor of Position
	 */
	public Position() {
		x = 0;
		y = 0;
	}
	
	/**
	 * A constructor of Position where you can set the desired coordinates
	 * @param xIn X coordinate
	 * @param yIn Y coordinate
	 */
	public Position(int xIn, int yIn) {
		x = xIn;
		y = yIn;
	}
	
	/**
	 * Returns the X coordinate of the Position
	 * @return X coordinate
	 */
	public int getX () {
		return x;
	}
	
	/**
	 * Sets the X coordinate of Position
	 * @param xIn the desired X coordinate
	 */
	public void setX (int xIn) {
		x = xIn;
	}
	
	/**
	 * Returns the Y coordinate of the Position
	 * @return Y coordinate
	 */
	public int getY () {
		return y;
	}
	
	/**
	 * Sets the Y coordinate of Position
	 * @param yIn the desired Y coordinate
	 */
	public void setY (int yIn) {
		y = yIn;
	}
}
