/**
 * A class designed to represent a destination
 * (where the player has to move the boxes) in Sokoban
 *
 */
public class Destination extends Block {
	
	private static final long serialVersionUID = -6389567532342462022L;

	/**
	 * The Constructor of Destination where you can set the position of it
	 * @param pos The desired Position of the created Destination
	 * @see Position
	 */
	public Destination(Position pos) {
		super(pos, BlockType.DESTINATION, false, false, null, null);
	}
	
	/**
	 * The Constructor of Destination where you can set the position of it,
	 * and a Block thats on the created Destination
	 * @param pos The desired Position of the created Destination
	 * @param ba The Block to put on top of the created Destination
	 * @see Position
	 */
	public Destination(Position pos, Block ba) {
		super(pos, BlockType.DESTINATION, false, true, ba, null);
	}
	
	/**
	 * Returns the type of Block that should be visible from above the map
	 * witch can be three types in a Destinations case:
	 * DESTINATION - if nothing is on top of it (null)
	 * BOXONDES - if a Box is on top
	 * CHARACTER - if the Character is on top
	 * @return The type of block to show
	 * @see BlockType
	 */
	@Override
	public BlockType getTypeToPrint() {
		if(hasBlockOnTop()) {
			if(getBlockAbove().getType().equals(Block.BlockType.BOX)) {
				return BlockType.BOXONDES;
			} else {
				return BlockType.CHARACTER;
			}			
		} else {
			return BlockType.DESTINATION;
		}
	}

}
