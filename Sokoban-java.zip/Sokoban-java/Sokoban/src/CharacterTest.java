import static org.junit.Assert.assertEquals;

/**
 * Test cases for the class Character
 */
import org.junit.Test;

public class CharacterTest {
	
	@Test
	public void testCharacter() {
		Position pos = new Position(4, 20);
		Character c = new Character(pos);
		assertEquals(pos, c.getPos());
		assertEquals(Block.BlockType.CHARACTER, c.getType());
		assertEquals(true, c.isMoveable());
		assertEquals(Block.BlockType.CHARACTER, c.getTypeToPrint());
		Floor f = new Floor(pos);
		f.setBlockAbove(c);
		f.setHasOnTop(true);
		c.setBlockBelow(f);
		assertEquals(Block.BlockType.CHARACTER, f.getTypeToPrint());
	}
	
	@Test
	public void testSetDir() {
		Position pos = new Position(4, 20);
		Character c = new Character(pos);
		assertEquals(Block.Direction.NORTH, c.getDir());
		c.setDir(10000);
		assertEquals(Block.Direction.NORTH, c.getDir());
		c.setDir(83);
		assertEquals(Block.Direction.SOUTH, c.getDir());
		c.setDir(39);
		assertEquals(Block.Direction.EAST, c.getDir());
		c.setDir('a');
		assertEquals(Block.Direction.WEST, c.getDir());
	}
}
