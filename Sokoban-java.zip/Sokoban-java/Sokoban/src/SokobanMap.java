
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.ArrayList;


/**
 * The class Sokoban map provides every tool needed to store all the information
 * about a level of the game Sokoban. It stores the elements of the map,
 * information about the player, and is able to direct a whole game on any given level.
 *
 */
public class SokobanMap implements Serializable{

	private static final long serialVersionUID = -5501089485204879144L;
	
	private String name;
	private int bestScore;
	private String bestScorePlayer;
	private int height;
	private int length;
	private Character character;
	private Box[] box;
	private Block[][] block;
	private int boxCount = 0;
	private int numberOfBoxes;
	private int stepsTaken = 0;
	/**
	 * The ChangedBlock class is able to store the relevant information
	 * about Blocks that changed during a step,
	 * so that the map can return that information to any potential method tat need it.
	 */
	public class ChangedBlock {
		Position pos;
		Block.BlockType type;
		public ChangedBlock(Position p, Block.BlockType t) {
			pos = p;
			type = t;
		}
		
		/**
		 * Returns the position of the ChangedBlock
		 * @return The Position of the ChangedBlock
		 */
		public Position getPos() {
			return pos;
		}
		
		/**
		 * Returns the type of the Changed Block
		 * @return The type of the ChangedBlock
		 * @see Block.BlockType
		 */
		public Block.BlockType getType() {
			return type;
		}
	}
	
	/**
	 * Constructor of the Class SokobanMap,
	 * that loads a given map from a text file.
	 * @param fileName Name of the text file from which the map will be loaded.
	 * @throws FileNotFoundException Throwed if the given text file cant be found
	 * @throws IOException 
	 */
	public SokobanMap(String fileName) throws FileNotFoundException, IOException {
		loadFromTxt(fileName);
	}
	
	/**
	 * Returns the name of the map
	 * @return Name of the map
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Returns the best score reached on the map
	 * (Basically ow many steps it took to complete, the lower the better)
	 * @return best score
	 */
	public int getBestScore() {
		return bestScore;
	}
	
	/**
	 * Returns the player that holds the best score for the map.
	 * null if the map hasn't been compleeted yet
	 * @return Best score holder
	 */
	public String getBestScorePlayer() {
		return bestScorePlayer;
	}
	
	/**
	 * Returns the height of the map
	 * @return height of the map
	 */
	public int getHeight() {
		return height;
	}
	
	/**
	 * Returns the width of the map
	 * @return width of the map
	 */
	public int getWidth() {
		return length;
	}
	
	/**
	 * Returns how many boxes are on the map
	 * @return number of boxes on the map
	 */
	public int getBoxCount() {
		return boxCount;
	}
	
	/**
	 * Sets the direction the character will be facing
	 * @param c The direction the character will face
	 * @see Block.Direction
	 */
	public void setCharDir(int c) {
		character.setDir(c);
	}
	
	/**
	 * Returns how many steps the player took so far
	 * @return number of steps taken
	 */
	public int getStepsTaken() {
		return stepsTaken;
	}
	
	/**
	 * Can set a new best score if needed
	 * @param bs the new best score
	 */
	public void setBestScore(int bs) {
		bestScore = bs;
	}

	/**
	 * Sets the new best score holder players name
	 * @param p the players name
	 */
	public void setBestScorePlayer(String p) {
		bestScorePlayer = p;
	}
	
	/**
	 * Performs a step based on a Direction (Use the characters Direction)
	 * Then returns the relevant information about blocks that changed during the step in an array.
	 * @param c The Direction of the step
	 * @return	An ArrayList<ChangedBlocks> that holds information about the changes on the map
	 * @throws IOException 
	 */
	ArrayList<ChangedBlock> step(int c) throws IOException {
		ArrayList<ChangedBlock> list = new ArrayList<>();
		character.setDir(c);
		Block currentBlock = character.getBlockBelow();
		Position nextPosition = currentBlock.getNextBlockPosition(character.dir);
		Block nextBlock = block[nextPosition.getX()][nextPosition.getY()];
		if(!nextBlock.hasBlockOnTop()) {
			character.setPos(nextPosition);
			character.setBlockBelow(nextBlock);
			nextBlock.setBlockAbove(character);
			nextBlock.setHasOnTop(true);
			currentBlock.setBlockAbove(null);
			currentBlock.setHasOnTop(false);
			list.add(new ChangedBlock(currentBlock.getPos(), currentBlock.getTypeToPrint()));
			list.add(new ChangedBlock(character.getPos(), Block.BlockType.CHARACTER));
			stepsTaken++;
		} else if(nextBlock.getBlockAbove().getType().equals(Block.BlockType.BOX)) {
			Position nextNextPosition = nextBlock.getNextBlockPosition(character.dir);
			Block nextNextBlock = block[nextNextPosition.getX()][nextNextPosition.getY()];
			if(!nextNextBlock.hasBlockOnTop()) {
				nextBlock.getBlockAbove().setPos(nextNextPosition);
				nextBlock.getBlockAbove().setBlockBelow(nextNextBlock);
				nextNextBlock.setBlockAbove(nextBlock.getBlockAbove());
				nextNextBlock.setHasOnTop(true);
				character.setPos(nextPosition);
				character.setBlockBelow(nextBlock);
				nextBlock.setBlockAbove(character);
				currentBlock.setBlockAbove(null);
				currentBlock.setHasOnTop(false);
				list.add(new ChangedBlock(currentBlock.getPos(), currentBlock.getTypeToPrint()));
				list.add(new ChangedBlock(nextBlock.getPos(), nextBlock.getTypeToPrint()));
				list.add(new ChangedBlock(nextNextBlock.getPos(), nextNextBlock.getTypeToPrint()));
				stepsTaken++;
			}
		}
		
		return list;
	}
	
	/**
	 * Returns a type to print (the upmost block in a coordinate)
	 * based on the gotten coordinates
	 * @param x - coordinate
	 * @param y - coordinate
	 * @return - The type to be shown
	 * @see Block.BlockType
	 */
	public Block.BlockType getBlockTypeToPrint(int x, int y) {
		return block[x][y].getTypeToPrint();
	}
	
	/**
	 * Returns true if the game is finished(if all boxes are in a destination)
	 * @return true if finished, false if not
	 */
	public boolean gameFinished() {
		for(Box b: box) {
			if(!(b.getBlockBelow().getType().equals(Block.BlockType.DESTINATION))) {
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Returns true if the player completed the level with a new high score
	 * Only interpreted if the game is finished
	 * @return true if the player set a new high score
	 */
	public boolean newHighScore() {
		return gameFinished() && (bestScore == 0 || stepsTaken < bestScore);
	}
	
	/**
	 * loads a Sokoban map from a .txt file
	 * (parameters specified in the user guide)
	 * @param fileName name and path of thhe file desired to be loaded
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public void loadFromTxt(String fileName) throws IOException, FileNotFoundException {
		try (
			FileInputStream fis = new FileInputStream(fileName);
			InputStreamReader isr = new InputStreamReader(fis);
			BufferedReader br = new BufferedReader(isr);
			) {
				String line;
				name = br.readLine();
				bestScore = Integer.parseInt(br.readLine());
				height = Integer.parseInt(br.readLine());
				length = Integer.parseInt(br.readLine());
				numberOfBoxes = Integer.parseInt(br.readLine());
				block = new Block[height][length];
				box = new Box[numberOfBoxes];
				for(int i = 0; i < height; i++) {
					line = br.readLine();
					for(int j = 0; j < length; j++) {
						switch(line.charAt(j)) {
						case 'C':
						case '@':
							character = new Character(new Position(i,j));
							block[i][j] = new Floor(new Position(i,j), character);
							character.setBlockBelow(block[i][j]);
							break;
						case 'B':
						case '$':
							box[boxCount] = new Box(new Position(i,j));
							block[i][j] = new Floor(new Position(i,j), box[boxCount]);
							box[boxCount].setBlockBelow(block[i][j]);
							boxCount++;
							break;
						case 'X':
						case '*':
							box[boxCount] = new Box(new Position(i,j));
							block[i][j] = new Destination(new Position(i,j), box[boxCount]);
							box[boxCount].setBlockBelow(block[i][j]);
							boxCount++;
							break;
						case 'O':
							block[i][j] = new Outside(new Position(i,j));
							break;
						case 'W':
						case '#':
							block[i][j] = new Wall(new Position(i,j));
							break;
						case 'F':
						case ' ':
							block[i][j] = new Floor(new Position(i,j));
							break;
						case 'D':
						case '.':
							block[i][j] = new Destination(new Position(i,j));
							break;
						default:
							throw new IOException("Beolvas�s hiba");
						}
					}
				}				
				
		} catch (IOException e) {
			throw e;
		}
		
	}
	
	/**
	 * Can print a map to the standard output(console)
	 * used for testing while the project was in development
	 */
	public void printToConsole() {
		for(int i = 0; i < height; i++) {
			for(int j = 0; j < length; j++) {
				switch(block[i][j].getTypeToPrint()) {
				case BLOCK: break;
				case OUTSIDE:
					System.out.print(" ");
					break;
				case WALL:
					System.out.print("/");
					break;
				case FLOOR:
					System.out.print(" ");
					break;
				case DESTINATION:
					System.out.print(".");
					break;
				case BOXONDES:
					System.out.print("X");
					break;
				case CHARACTER:
					System.out.print("O");
					break;
				case BOX:
					System.out.print("@");
					break;
				}
			}
			System.out.print("\n");
		}
	}
}
