import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * Test cases for the class Block
 *
 */
public class BlockTest {

	@Test
	public void testBlock() {
		Block b = new Block();
		assertEquals(b.getTypeToPrint(), Block.BlockType.BLOCK);
		assertEquals(b.getBlockAbove(), null);
		assertEquals(b.getBlockBelow(), null);
	}
	
	@Test
	public void testBlockGetSet() {
		Position pos = new Position(10,10);
		Block b = new Block(pos, Block.BlockType.BLOCK, false, false, null, null);
		assertEquals(b.getBlockAbove(), null);
		assertEquals(b.getBlockBelow(), null);
		assertEquals(b.getPos(), pos);
		assertEquals(b.getTypeToPrint(), b.getType());
		Block ba = new Block();
		b.setBlockAbove(ba);
		b.setHasOnTop(true);
		ba.setBlockBelow(b);
		assertEquals(b.hasBlockOnTop(), true);
		assertEquals(b.getBlockAbove(), ba);
		assertEquals(ba.getBlockBelow(), b);
		assertEquals(b.isMoveable(), false);
	}
}
