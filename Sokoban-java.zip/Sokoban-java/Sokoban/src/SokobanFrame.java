import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * This class creates a windowed wersion of the game Sokoban using
 * the GUI java.swing, and uses the SokobanMap class as a controller
 *
 */
public class SokobanFrame extends JFrame{
	
	private static final long serialVersionUID = -2419093308385938383L;
	
	private String playerName;
	private SokobanMap map;
	private String selectedMap;
	private int numberOfMaps;
	JFrame gameFinishedFrame;
	
	
	/**
	 * Initialises the menu of the game,
	 * where the player can type in his/her player name,
	 * can chose a map to play
	 * and can even import new maps from a .txt file (parameters specifiedin the user guide)
	 * @throws IOException Thrown if the chosen maps file couldnt be found
	 */
	private void initWelcomeFrame() throws IOException {
		this.setLayout(new BorderLayout());
		JPanel namePanel = new JPanel();
		JLabel nameLabel = new JLabel("Player name:");
		JTextField nameTextField = new JTextField("Player1", 11);		
		namePanel.add(nameLabel);
		namePanel.add(nameTextField);
		
		BufferedImage myPicture = ImageIO.read(new File("images/zika.png"));
		JLabel picLabel = new JLabel(new ImageIcon(myPicture));
		
		JPanel welcomePanel = new JPanel();
		welcomePanel.setLayout(new BoxLayout(welcomePanel, BoxLayout.Y_AXIS));
		welcomePanel.add(picLabel);
		welcomePanel.add(namePanel);
		
		try (
				FileInputStream fin = new FileInputStream("maps/numberOfMaps.txt");
				InputStreamReader isr = new InputStreamReader(fin);
				BufferedReader br = new BufferedReader(isr);
				){			
			numberOfMaps = Integer.parseInt(br.readLine());
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		
		Object[] mapsArr = new Object[numberOfMaps];
		for(int i = 0; i < numberOfMaps; i++) {
			String s = "Level " + (i + 1);
			mapsArr[i] = s;
		}
		@SuppressWarnings({ "rawtypes", "unchecked" })
		JComboBox mapsComboBox = new JComboBox(mapsArr);
		JLabel mapsLabel = new JLabel("Chose level:");
		JButton okButton = new JButton("Ok");
		
		/**
		 * If the Start button is pressed loads the chosen map
		 * using initGameFrame()
		 *
		 */
		final class StartButtonListener implements ActionListener {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String selectedMapName = (String)mapsComboBox.getSelectedItem();
				String mapNumber = selectedMapName.replace("Level ", "");
				selectedMap = "maps/map" + mapNumber + ".ser";
				
				map = readMap(selectedMap);
				playerName = nameTextField.getText();
				try {
				initGameFrame(welcomePanel);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
        	
        }
		okButton.addActionListener(new StartButtonListener());
		
		JPanel mapsPanel = new JPanel();
		mapsPanel.add(mapsLabel);
		mapsPanel.add(mapsComboBox);
		mapsPanel.add(okButton);
		welcomePanel.add(mapsPanel);
		
		JLabel importLabel = new JLabel("Import level: ");
		JTextField importTextField = new JTextField("file and path", 12);
		JButton importButton = new JButton("Import");
		
		/**
		 * Listener for the "Import button"
		 * if the button is clicked this method attempts to import a map
		 * from a .txt file based on the text in "importTextField".
		 * After running its specified in "importTextField"
		 * whether the import was succesful or not.
		 */
		final class ImportButtonListener implements ActionListener {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				SokobanMap mapImport;
				numberOfMaps++;
				try {
					mapImport = new SokobanMap(importTextField.getText());
					
					try (
							FileOutputStream f = new FileOutputStream("maps/map" + numberOfMaps + ".ser");
							ObjectOutputStream out = new ObjectOutputStream(f);
							){
							out.writeObject(mapImport);
							importTextField.setText("Imported: " + mapImport.getName());
						}					
					catch (IOException e) {
						throw e;
					}
				} catch (FileNotFoundException e) {
					String filePath = importTextField.getText();
					importTextField.setText("File not found: " + filePath);
					numberOfMaps--;
				} catch (IOException e) {
					e.printStackTrace();
				}
				try (
						FileOutputStream f2 = new FileOutputStream("maps/numberOfMaps.txt");
						OutputStreamWriter ow = new OutputStreamWriter(f2);
						){
					ow.write(numberOfMaps + "\n");
				} catch (IOException e) {
					e.printStackTrace();
				}
							
			}
			
		}
		importButton.addActionListener(new ImportButtonListener());
		
		JPanel importPanel = new JPanel();
		importPanel.add(importLabel);
		importPanel.add(importTextField);
		importPanel.add(importButton);
		welcomePanel.add(importPanel);
		
		this.add(welcomePanel);
		this.pack();
		this.setVisible(true);
		
	}
	
	/**
	 * Builds the map in a JFrame using GridLayout.
	 * Manages the game by listening to KeyPresses.
	 * Also displays information about the game on the side like:
	 * Players name, steps taken, high score to beat, etc..
	 * @param p The JPanel that was displayed on the Frame before the statrt of the game.
	 * needs to get it so it can remove it and replace it
	 * @throws IOException
	 */
	public void initGameFrame(JPanel p) throws IOException {
		this.remove(p);
		JLabel mapNameLabel = new JLabel(map.getName());
		JLabel nameLabel = new JLabel("Player name: " + playerName);
		JPanel stepsPanel = new JPanel();
		JLabel stepsTakenLabel = new JLabel("StepsTaken:");
		JTextField stepsTakenTextField = new JTextField("", 3);
		stepsTakenTextField.setHorizontalAlignment(JTextField.RIGHT);;
		stepsTakenTextField.setEditable(false);
		Integer temp = map.getStepsTaken();
		stepsTakenTextField.setText(temp.toString());
		stepsTakenTextField.setSize(new Dimension(1, 20));
		
		stepsPanel.add(stepsTakenLabel);
		stepsPanel.add(stepsTakenTextField);
		
		JButton startButton = new JButton("Start");
		startButton.setActionCommand("Start");
		JButton resetButton = new JButton("Reset");
		resetButton.setActionCommand("Reset");
		JPanel buttonsPanel = new JPanel();
		buttonsPanel.setAlignmentX(LEFT_ALIGNMENT);
		JPanel gameInfoPanel = new JPanel();
		gameInfoPanel.setLayout(new BoxLayout(gameInfoPanel, BoxLayout.Y_AXIS));
		gameInfoPanel.add(mapNameLabel);
		gameInfoPanel.add(nameLabel);
		gameInfoPanel.add(stepsPanel);
		JLabel bestScoreToBeatLabel;
		JLabel bestScoreToBeatLabel2;
		if(map.getBestScorePlayer() != null) {
			bestScoreToBeatLabel = new JLabel("Best completion: " + map.getBestScore());
			bestScoreToBeatLabel2 =new JLabel("By: " + map.getBestScorePlayer());
			gameInfoPanel.add(bestScoreToBeatLabel);
			gameInfoPanel.add(bestScoreToBeatLabel2);
		} else {
			bestScoreToBeatLabel = new JLabel("Noone completed this map yet!");
			gameInfoPanel.add(bestScoreToBeatLabel);
		}
		
		
		buttonsPanel.add(startButton);
		buttonsPanel.add(resetButton);
		gameInfoPanel.add(buttonsPanel);
		
		JButton returnButton = new JButton("Return to menu");
		returnButton.setActionCommand("Return to menu");
		gameInfoPanel.add(returnButton);
		JPanel gamePanel = new JPanel();
		
		JPanel gameMapPanel = new JPanel(new GridLayout(map.getHeight(), map.getWidth()));
		gameMapPanel.setFocusable(true);
		
		for(int i = 0; i < map.getHeight(); i++) {
			for(int j = 0; j < map.getWidth(); j++) {
				gameMapPanel.add(getPicture(map.getBlockTypeToPrint(i, j)));
			}
		}
		gamePanel.add(gameMapPanel);
		gamePanel.add(gameInfoPanel);
		
		/**
		 * Listener for the contents of gamePanel.
		 * Performs steps based on key presses,
		 * updates the information in the infoPanel
		 * and checks if the game is finished.
		 *
		 */
		final class GameListener implements KeyListener , ActionListener{

			@Override
			public void keyPressed(KeyEvent keyP) {
				switch(keyP.getKeyCode()) {	
				default:
					try {
						List<SokobanMap.ChangedBlock> list = map.step(keyP.getKeyCode());
						for(SokobanMap.ChangedBlock cb: list) {
							int idx = cb.getPos().getX() * map.getWidth() + cb.getPos().getY();
							gameMapPanel.remove(idx);
							gameMapPanel.add(getPicture(cb.getType()), idx);
						}
					} catch (IOException e) {
						e.printStackTrace();
					}
					Integer temp = map.getStepsTaken();
					stepsTakenTextField.setText(temp.toString());
					
					if(map.gameFinished()) {
						gameFinishedFrame = new JFrame("Sokoban");
						JTextArea gameFinishedTextArea = new JTextArea();
						gameFinishedTextArea.setMargin(new Insets(8, 8, 8, 8));
						gameFinishedTextArea.setEditable(false);
						
						if(map.newHighScore()) {
							gameFinishedTextArea.setText("Game finished.\nCongratulations you set a new high score\nwith only "
														+ map.getStepsTaken() + " steps taken!");
							
							int stepsTemp = map.getStepsTaken();
							map = readMap(selectedMap);
							map.setBestScore(stepsTemp);
							map.setBestScorePlayer(playerName);
							try (
									FileOutputStream f = new FileOutputStream(selectedMap);
									ObjectOutputStream out = new ObjectOutputStream(f);
									){
									out.writeObject(map);
								}
								catch (IOException e) {
									System.out.println(e.getMessage());
								}
						} else if (map.getBestScore() == map.getStepsTaken()){
							gameFinishedTextArea.setText("Game finished.\nYou matched the high score\nof only "
									+ map.getBestScore() + " steps taken.");
						} else {
							gameFinishedTextArea.setText("Game finished.\nYou couldn't beat the high score\nof only "
									+ map.getBestScore() + " steps taken.\nIt took you "
									+ map.getStepsTaken() + " steps to beat the level.");
						}
						gameFinishedFrame.add(gameFinishedTextArea, BorderLayout.CENTER);
						gameFinishedFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
						gameFinishedFrame.add(returnButton, BorderLayout.SOUTH);
						gameFinishedFrame.pack();
						gameFinishedFrame.setVisible(true);
					}
					gameMapPanel.validate();
					gameMapPanel.repaint();					
					break;
				}
				
			}

			@Override
			public void keyReleased(KeyEvent arg0) {
				
			}

			@Override
			public void keyTyped(KeyEvent keyPressed) {
				
				
			}

			@Override
			public void actionPerformed(ActionEvent button) {
				if(button.getActionCommand().equals("Reset")) {					
					map = readMap(selectedMap);
					
					gameMapPanel.removeAll();
					
					for(int i = 0; i < map.getHeight(); i++) {
						for(int j = 0; j < map.getWidth(); j++) {
							gameMapPanel.add(getPicture(map.getBlockTypeToPrint(i, j)));
						}
					}
					Integer temp = map.getStepsTaken();
					stepsTakenTextField.setText(temp.toString());
					if(map.gameFinished()) {
						
					}
					gamePanel.validate();
					gamePanel.repaint();
				}
				
				if(button.getActionCommand().equals("Return to menu")) {
					if(map.gameFinished()) {
						gameFinishedFrame.dispose();
					}
					gamePanel.getParent().removeAll();
					try {
						initWelcomeFrame();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				
			}			
		}
		
		GameListener listener = new GameListener();
		gameMapPanel.addKeyListener(listener);
		gameInfoPanel.addKeyListener(listener);
		startButton.addKeyListener(listener);
		startButton.addActionListener(listener);
		resetButton.addActionListener(listener);
		resetButton.addKeyListener(listener);
		returnButton.addActionListener(listener);
		
		this.add(gamePanel, BorderLayout.CENTER);
		this.pack();
		this.validate();
		this.repaint();
		
		
	}
	
	/**
	 * Deserialises given map from its .ser file
	 * based on a given string.
	 * @param selectedMap The file path and name of the desired file
	 * @return Instance of the deserialised map
	 */
	private SokobanMap readMap(String selectedMap) {
		SokobanMap map = null;
		try (
				FileInputStream f = new FileInputStream(selectedMap);
				ObjectInputStream in = new ObjectInputStream(f);
			){
				map = (SokobanMap)in.readObject();
			}
			catch (IOException e) {
					System.out.println(e.getStackTrace());
			}
			catch (ClassNotFoundException e) {
				System.out.println(e.getMessage());
			}
		return map;
	}
	
	/**
	 * Loads and retrns the pictures needed to paint
	 * any given SokobanMap
	 * @param type The type of the Block desired to paint
	 * @see Block.BlockType
	 * @return A JLabel that contains the picture matching the Block type
	 */
	private JLabel getPicture(Block.BlockType type) {
		switch(type) {
		case BLOCK: break;
		case BOX:
			try {
				BufferedImage boxPicture = ImageIO.read(new File("images/box.png"));
				JLabel boxLabel = new JLabel(new ImageIcon(boxPicture));
				return boxLabel;
			}
			catch(IOException e) {
				System.out.println(e.getMessage());
			}
			break;
			
		case BOXONDES:
			try {
				BufferedImage boxondesPicture = ImageIO.read(new File("images/boxondes.png"));
				JLabel boxondesLabel = new JLabel(new ImageIcon(boxondesPicture));
				return boxondesLabel;
			}
			catch(IOException e) {
				System.out.println(e.getMessage());
			}
			break;
			
		case CHARACTER:
			try {
				BufferedImage characterPicture = ImageIO.read(new File("images/character.png"));
				JLabel characterLabel = new JLabel(new ImageIcon(characterPicture));
				return characterLabel;
			}
			catch(IOException e) {
				System.out.println(e.getMessage());
			}
			break;
		
		case DESTINATION:
			try {
				BufferedImage destinationPicture = ImageIO.read(new File("images/destination.png"));
				JLabel destinationLabel = new JLabel(new ImageIcon(destinationPicture));
				return destinationLabel;
			}
			catch(IOException e) {
				System.out.println(e.getMessage());
			}
			break;
		
		case FLOOR:
			try {
				BufferedImage floorPicture = ImageIO.read(new File("images/floor.png"));
				JLabel floorLabel = new JLabel(new ImageIcon(floorPicture));
				return floorLabel;
			}
			catch(IOException e) {
				System.out.println(e.getMessage());
			}
			break;
		
		case OUTSIDE:
			try {
				BufferedImage outsidePicture = ImageIO.read(new File("images/outside.png"));
				JLabel outsideLabel = new JLabel(new ImageIcon(outsidePicture));
				return outsideLabel;
			}
			catch(IOException e) {
				System.out.println(e.getMessage());
			}
			break;
		
		case WALL:
			try {
				BufferedImage wallPicture = ImageIO.read(new File("images/wall.png"));
				JLabel wallLabel = new JLabel(new ImageIcon(wallPicture));
				return wallLabel;
			}
			catch(IOException e) {
				System.out.println(e.getMessage());
			}
			break;
		
		default: break;
		}
		throw new IllegalStateException("Gond van");
	}
		
	/**
	 * The constructor of SokobanFrame.
	 * sets up the default close operation
	 * and makes the frame unresizeable
	 * then calls initWelcomeFrame.
	 */
	public SokobanFrame() {
		super("Sokoban");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		try {
			initWelcomeFrame();
		}
		catch (IOException e) {
			System.out.println(e.getStackTrace());
		}
	}
	
	 public static void main(String[] args) {
	        SokobanFrame sokobanFrame = new SokobanFrame();
	        sokobanFrame.setVisible(true);
	    }
}
