/**
 * A class designed to represent the character in Sokoban
 *
 */
public class Character extends Block {

	private static final long serialVersionUID = 5677371721532079370L;
	Direction dir;
	
	/**
	 * The Constructor of Character where you can set the position of it
	 * @param pos The desired Position of the created Character
	 * @see Position
	 */
	public Character(Position pos) {
		super(pos, BlockType.CHARACTER, true, false, null, null);
		dir = Direction.NORTH;
	}
	
	/**
	 * Returns the Direction the Character is faceing
	 * (The direction it will step if map.step() is called)
	 * @return The Direction the Character is faceing
	 * @see Direction
	 */
	public Direction getDir() {
		return dir;
	}

	/**
	 * Sets the Direction the Character is faceing
	 * (The direction it will step if map.step() is called)
	 * based on a pressed key
	 * @param c can be KeyCode for w, a, s, d and (up, down, left, right) arrow keys
	 * @see Direction
	 */
	public void setDir(int c) {
		switch(c) {
		case 87:
		case 38: 
		case 'w':
			dir = Direction.NORTH; break;
		case 83:
		case 40:
		case 's':
			dir = Direction.SOUTH; break;
		case 68:
		case 39:
		case 'd':
			dir = Direction.EAST; break;
		case 65:
		case 37:
		case 'a':
			dir = Direction.WEST; break;
		default: break;
		}
	}
	
}
