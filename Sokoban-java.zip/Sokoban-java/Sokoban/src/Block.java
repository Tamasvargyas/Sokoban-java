import java.io.IOException;
import java.io.Serializable;

/**
 * The superclass of the building blocks
 * of a Sokoban level.
 *
 */
public class Block implements Serializable {

	private static final long serialVersionUID = -4130775643204119316L;
	
	/**
	 * Directions used to specify the way the character will be stepping.
	 *
	 */
	public enum Direction {
		NORTH, SOUTH, EAST, WEST
	}
	
	/**
	 * An enum with all the possible types of blocks
	 *
	 */
	public enum BlockType {
		BOX, BOXONDES, CHARACTER, DESTINATION, FLOOR, OUTSIDE, WALL, BLOCK 
	}
	/**
	 * The position of the block
	 * @see Position
	 */
	private Position position;
	private BlockType type;
	private boolean moveable;
	private boolean hasOnTop;
	private Block blockAbove;
	private Block blockBelow;
	
	/**
	 * Default constructor of Block
	 */
	public Block() {
		position = new Position();
		type = BlockType.BLOCK;
		moveable = false;
		hasOnTop = false;
		blockAbove = null;
	}
	
	/**
	 * A constructor of block where all attributes can be set
	 * @param pos The position of the block
	 * @param tpe The type of the block
	 * @param mov If the Block is moveable
	 * @param hot If the Block has another block on top of it
	 * @param ba The Block above, if there is none set null
	 * @param bo The Block below, if there is none set null
	 */
	public Block(Position pos, BlockType tpe, boolean mov, boolean hot, Block ba, Block bo) {
		position = pos;
		type = tpe;
		moveable = mov;
		hasOnTop = hot;
		blockAbove = ba;
		blockBelow = bo;
	}
	
	/**
	 * Setter for the Position of the block
	 * @param p The position of the block
	 * @see Position
	 */
	public void setPos(Position p) {
		position = p;
	}
	
	/**
	 * Getter for the position of the Block
	 * @return The position of the Block
	 * @see Position
	 */
	public Position getPos() {
		return position;
	}
	
	/**
	 * Setter for the type of the Block
	 * @param tpe The type of the Block
	 * @see BlockType
	 */
	public void setType(BlockType tpe) {
		type = tpe;
	}
	
	/**
	 * Getter for the type of the Block
	 * @return tpe The type of the Block
	 * @see BlockType
	 */
	public BlockType getType() {
		return type;
	}
	
	/**
	 * Returns if the Block is moveable
	 * @return true if the block is moveable, false if not
	 */
	public boolean isMoveable() {
		return moveable;
	}
	
	/**
	 * Set if the Block has another Block on top of it
	 * @param hot true if it has another on top, false if not
	 */
	public void setHasOnTop(boolean hot) {
		hasOnTop = hot;
	}
	
	/**
	 * Returns if the Block has another Block on top of it
	 * @return true if there is another Block on top, false if not
	 */
	public boolean hasBlockOnTop() {
		return hasOnTop;
	}
	
	/**
	 * Put a Block on top of this one
	 * @param b The Block to put on top, set null to remove
	 */
	public void setBlockAbove(Block b) {
		blockAbove = b;
	}
	
	/**
	 * Get the Block above this one
	 * @return A Block that is on top of this one, returns null if there is none
	 */
	public Block getBlockAbove() {
		return blockAbove;
	}
	
	/**
	 * Put a Block below this one
	 * @param b The Block to put below, set null to remove
	 */
	public void setBlockBelow(Block b) {
		blockBelow = b;
	}
	
	/**
	 * Get the Block below this one
	 * @return A Block that is below this one, returns null if there is none
	 */
	public Block getBlockBelow() {
		return blockBelow;
	}
	
	/**
	 * Returns the type of Block that should be visible from above the map
	 * @return Varies by the type of block
	 * @see BlockType
	 */
	public BlockType getTypeToPrint() {
		return getType();
	}
	
	/**
	 * Get the position of the next Block based on a direction
	 * @param dir The Direction in whitch we want to get the next Block
	 * @see Direction
	 * @return The Position of the next Block
	 * @see Position
	 * @throws IOException Throwed in case of impossible direction
	 */
	public Position getNextBlockPosition(Direction dir) throws IOException {
		switch(dir) {
		case NORTH:
			return new Position(getPos().getX() - 1,getPos().getY());
		case SOUTH:
			return new Position(getPos().getX() + 1,getPos().getY());
		case EAST:
			return new Position(getPos().getX(), getPos().getY() + 1);
		case WEST:
			return new Position(getPos().getX(), getPos().getY() - 1);
		default:
			throw new IOException("Character direction error");
		}
	}
	
	
	
}
