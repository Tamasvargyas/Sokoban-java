/**
 * A class designed to represent a unit of the outside in Sokoban
 *
 */
public class Outside extends Block {

	private static final long serialVersionUID = 6287597415179858590L;

	/**
	 * The Constructor of Outside where you can set the position of it
	 * @param pos The desired Position of the created Outside
	 * @see Position
	 */
	public Outside(Position pos) {
		super(pos, BlockType.OUTSIDE, false, false, null, null);
	}

}
